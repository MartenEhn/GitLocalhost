<?php
/**
 * Deprecated. No longer needed.
 *
 * @package WordPress
 */
_deprecated_file( basename(__FILE__), '3.1', null, __( 'This file no longer needs to be included.' ) );
